`Annoybot`

just know that this bot will annoy your friends within small servers with
- roasts
- trolling
- uninspirational quotes
- memes
- bad jokes
- (to be updated) math functions and formulae

add the bot here please i beg:
https://discordbotlist.com/bots/annoybot-4074
support:
https://discord.gg/UCGAuRXmBD